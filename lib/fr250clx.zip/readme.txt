FastReport CLX 2.5
for Delphi 6/7, C++Builder 6 and Kylix 1/2/3

READ THIS FILE ACCURATELY BEFORE INSTALLING FR CLX!

----------------------------------------------------------------------------
TABLE OF CONTENTS

1. Introduction
2. Capabilities
3. Installing
4. Backward compatibility
5. Ordering
6. Notes
7. Credits


----------------------------------------------------------------------------
1. INTRODUCTION
   FastReport is reporting tool component. It consists of report engine,
designer and preview. Its capabilities comparable with in ReportBuilder 5.xx.
It written on 100% Object Pascal and can be installed in Delphi 6,7, CBuilder 6
and Kylix 1,2,3.
   FastReport CLX is SHAREWARE. See "Ordering" topic for details.


----------------------------------------------------------------------------
2. CAPABILITIES
- Band-oriented report generator.
- Built-in powerful designer, also available in run-time.
- Preview like in MS Word.
- Unlimited number of pages in prepared report.
- Multi-page reports; composite reports; subreports; groups;
  multi-column reports; master-detail-detail reports;
  cross-tab reports; two-pass reports; "live" reports.
- Full control over printing process; support all paper sizes.
- Set of most useful components: Text, Line, Picture, Shape, Barcode.
- TXT, RTF, CSV, HTML export (RTF and HTML - with pictures).
- Text search in prepared report.
- Editing pages of prepared report.
- Built-in Pascal-like interpreter for handling of building process.
- Report form can store in DFM resources, external file, BLOb field
  of DB table, or in stream.
- Ability of expanding functionality by own report components, wizards,
  function libraries.

----------------------------------------------------------------------------
3. INSTALLING
   Before installing, remove any other version of FastReport from the
Delphi/Kylix component palette. Create a folder under your Delphi folder,
typically FRCLX and decompress the files in clxcore.zip, clxreg.zip
(or clxtrial.zip, if you evaluating FR) to this directory.

   FR includes full source code. Trial version contains almost all sources
(only one compiled unit). Before installing, you should copy this unit
from ..\FRCLX\LIB_D6 (Delphi6) or ..\FRCLX\LIB_K2(3) to ..\FRCLX\SOURCE.

3.1. Delphi 6.
   Copy file FR_Class.dcu from ..\FRCLX\LIB_D6 to ..\FRCLX\SOURCE (if you have
trial version of FR).
   Run Delphi, choose "File/Open..." menu command and open package
FRX.dpk from ..\FRCLX\SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into Delphi.
   After installing, "FastReport" and "FR Tools" tabs appears in Delphi's
components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ..\FRCLX\SOURCE directory to the "Library path" string.

3.2. Delphi 7.
   Copy file FR_Class.dcu from ..\FRCLX\LIB_D7 to ..\FRCLX\SOURCE (if you have
trial version of FR).
   Run Delphi, choose "File/Open..." menu command and open package
FRX.dpk from ..\FRCLX\SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into Delphi.
   After installing, "FastReport" and "FR Tools" tabs appears in Delphi's
components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ..\FRCLX\SOURCE directory to the "Library path" string.

3.3. C++Builder 6.0.
   Copy files FR_Class.obj, FR_Class.hpp from ..\FRCLX\LIB_CB6 and FR_Class.dcu
from ..\FRCLX\LIB_D6 to ..\FRCLX\SOURCE (if you evaluating FR).
   Run C++Builder, choose "File/Open..." menu command and open package
FRX.dpk from ..\FRCLX\SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into IDE. After installing, "FastReport" and "FR Tools" tabs
appears in C++Builder components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ..\FR\SOURCE directory to the "Library path" string.
AFTER INSTALLING YOU SHOULD REBOOT C++BUILDER!

3.4. Kylix 1.
   Copy files from ../FRCLX/LIB_K1 to ../FRCLX/SOURCE (if you have
trial version of FR).
   Run Kylix, choose "File/Open..." menu command and open package
FRX.dpk from ../FRCLX/SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into Kylix.
   After installing, "FastReport" and "FR Tools" tabs appears in Kylix's
components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ../FRCLX/SOURCE directory to the "Library path" string.

3.5. Kylix 2.
   Copy files from ../FRCLX/LIB_K2 to ../FRCLX/SOURCE (if you have
trial version of FR).
   Run Kylix, choose "File/Open..." menu command and open package
FRX.dpk from ../FRCLX/SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into Kylix.
   After installing, "FastReport" and "FR Tools" tabs appears in Kylix's
components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ../FRCLX/SOURCE directory to the "Library path" string.

3.6. Kylix 3 Delphi.
   Copy files from ../FRCLX/LIB_K3 to ../FRCLX/SOURCE (if you have
trial version of FR).
   Run Kylix Delphi, choose "File/Open..." menu command and open package
FRX.dpk from ../FRCLX/SOURCE. In package editor, choose "Compile" button
to compile package. After compiling, press "Install" button to install
package into Kylix.
   After installing, "FastReport" and "FR Tools" tabs appears in Kylix's
components palette.
   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ../FRCLX/SOURCE directory to the "Library path" string.

3.7. Kylix 3 C++.
  
 WARNING! Strongly use described below step-by-step instruction!

-   Copy files from ../frclx/lib_k3cpp to ../frclx/source (if you have
trial version of FR).
-   Run Kylix Delphi.
-   Choose "File/Close All".
-   Choose "File/Open..." menu command and open package 
frx.dpk from ../frclx/source.
-   In package editor, choose "Compile" button to compile package.
-   Close Kylix Delphi.

-   Run Kylix C++.
-   Choose "File/Close All".
-   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ../frclx/source directory to the "Library path" string.
-   Choose "File/Open..." menu command and open package frxc.bpkl 
from ../frclx/source.
-   In package editor, choose "Compile" button to compile package.
-   Shrug off on errors.
-   Choose "File/Close All".
-   Choose "Component/Install Packages/Add" and select file bplfrx.so 
from ../frclx/source.
-   Choose "OK" button.

-   Copy file fr_api.hpp from ../frclx/lib_k3cpp to ../frclx/source 
(replace existing).


3.8. Installing additional components.
   There are two additional components included in standard FR package.
These components can be found in SOURCE\IBX (only for Windows) and 
SOURCE\DBX folders.
Each component have a package file.

3.9. Installing DBX components in Kylix 3 C++.

   WARNING! Strongly use described below step-by-step instruction!

-   Run Kylix Delphi.
-   Choose "File/Close All".
-   Choose "File/Open..." menu command and open package 
frx_dbx.dpk from ../frclx/source/dbx.
-   In package editor, choose "Compile" button to compile package.
-   Close Kylix Delphi.

-   Run Kylix C++.
-   Choose "File/Close All".
-   Choose "Tools/Environment options..." menu command. Go "Library" tab
and add path to ../frclx/source/dbx directory to the "Library path" string.
-   Choose "File/Open..." menu command and open package dbxc.bpkl 
from ../frclx/source/dbx.
-   In package editor, choose "Compile" button to compile package.
-   Shrug off on errors.
-   Choose "File/Close All".
-   Choose "Component/Install Packages/Add" and select file bplfrx_dbx.so 
from ../frclx/source/dbx.
-   Choose "OK" button.

-   Copy file fr_api.hpp from ../frclx/lib_k3cpp to ../frclx/source 
(replace existing).

3.10 Kylix 3 C++ Qt bug (compilation errors in Kylix 3 C++).
If you have errors on compilation in future 
(after installation addiotional components):
[C++ Error] fr_api.hpp(23): E2015 Ambiguity between 'QRegionH' and 'Qt:QRegionH'
... etc.
simply replace in fr_api.hpp:
'QRegionH' on 'QRegion__'
'QPainterH' on 'QPainter__'
'QBrushH' on 'QBrush__'

or copy file fr_api.hpp from ../frclx/lib_k3cpp to ../frclx/source 
(replace existing)

----------------------------------------------------------------------------
4. BACKWARD COMPATIBILITY
   You can open any .frf files from FR2.1...FR2.47 in FR CLX. FR CLX files 
can be opened only in FR2.45 and higher.

----------------------------------------------------------------------------
5. REGISTERING
   FastReport CLX is shareware. You can try trial version of FR, which
prints only one page of report with nag label "FastReport - unregistered".
Full version of FR shipped with full source code.
   Single copy of FR costs $99. Site license (unlimited number of copies)
costs $990. You can register it with RegisterNow! or ShareIt online services
which accepts all kinds of payment.

To register with ShareIt go to:
https://secure.element5.com/shareit/checkout.html?productid=155771&language=English

To register Fast Report CLX Site license with ShareIt go to:
https://secure.element5.com/shareit/checkout.html?productid=168090&language=English

To register with RegisterNow! go to:
https://www.regnow.com/softsell/nph-softsell.cgi?item=2749-3

To register Fast Report CLX Site license with RegisterNow! go to:
https://www.regnow.com/softsell/nph-softsell.cgi?item=2749-4

Registered users gets technical support and can upgrade to the next
version of FR with no additional payment.
See Dealers.txt for more information about our resellers in countries.
Read more on the FR home page http://www.fast-report.com, "Order Now" reference.

----------------------------------------------------------------------------
6. NOTES
   All units written by author, except the following:
 - Barcode component (frBarcod.pas) is written by Andreas Schmidt
   and friends (freeware).
 - See also "CREDITS" topic.

   Images - MS Windows, MS Office, Delphi\Images.
   Ideology - 1S-Bookkeeping 6.0, MS Office, Delphi.


----------------------------------------------------------------------------
7. CREDITS

Olivier Guilbaud <golivier@free.fr>:
 - Barcode add-in (FR_BarC.pas)
 - RoundRect add-in (FR_RRect.pas)

Andrew Semack <sammy@profix.poltava.ua>:
 - Interface with IB_Objects

EMS Company, Alexander Khvastunov <avx@ems.chel.su>:
 - TfrIBXComponents

Andrew Dyrda <andrewdyrda@chat.ru>:
 - Documentation

Konstantin Butov <kos@sp.iae.nsk.su>:
 - Idea and first version of TfrPrintGrid component

Sergey Repalov <ReSerg@mail.ru>:
 - TfrRTF_RS_ExportFilter

Stalker <stalker732_4@yahoo.com>:
 - A lot of suggestions and bug reports

Boris Loboda <barry@audit.kharkov.com>:
 - Help with hosting

Akzhan Abdulin <akzhan@mtgroup.ru>:
 - Life-time "moderatorial [-]" in RU.DELPHI :))

Pavel Ishenin <webpirat@mail.ru>
 - RTF, HTM export;


Localization:
 - Carsten Bech <carsten.bech@teliamail.dk> (danish)
 - Wy <wy6688@163.net> (chinese)
 - Roberto Mambriani <rmambriani@fasanocomputers.com> (italian)
 - Bartlomiej Zass <zass@pro.onet.pl> (polish)
 - Bolek Umnicki <strato@polandmail.com> (polish)
 - Josep Mas <xci@jet.es> (catalan)
 - Nei <coopcred@leosoft.com.br> (portuguese-brazil)
 - Isaque Pinheiro <axial@escelsa.com.br> (portuguese-brazil)
 - Bobby Gallagher <bobbyg@indigo.ie> (english)
 - Francisco Purrinos <purrinhos@cif.es> (spanish)
 - Andreas Pohl <apohl@ibp-consult.com> (german)
 - Stefan Diestelmann <sd@itsds.de> (german)
 - Arpad Toth <ekosoft@signalsoft.sk> (czech, slovak)
 - Le Hung <lehung@main.antszbar.hu> (hungary)
 - Tochenjuk Oleg <frodo@uct.kiev.ua> (ukrainian)
 - Pierre Demers <dempier2@hotmail.com> (french)
 - Olivier Guilbaud <golivier@free.fr> (french)
 - Craig Manley <c.manley@chello.nl> (dutch)
 - Burhan Chakmak <info@aydin.kz> (turkish)
 - Jan W <jan@ideida.se> (swedish)
 - Primoz Planinc <info@planles.net> (slovene)

Also thanks to all FR users who sent bugreports and suggestions!

----------------------------------------------------------------------------
Author:    FastReports Inc.
e-mail:    support@fast-report.com
home page: http://www.fast-report.com
           http://www.fastexperts.com