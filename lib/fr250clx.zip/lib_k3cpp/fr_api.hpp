// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'fr_api.pas' rev: 6.00

#ifndef fr_apiHPP
#define fr_apiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Types.hpp>	// Pascal unit
#include <Qt.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fr_api
{
//-- type declarations -------------------------------------------------------
typedef QRegion__ frHRGN;
;

typedef QPainter__ frHDC;
;

typedef QBrush__ frHBrush;
;

//-- var, const, procedure ---------------------------------------------------
static const Shortint frNULLREGION = 0x0;
static const Shortint frRGN_AND = 0x1;
static const Shortint frRGN_DIFF = 0x2;
static const Shortint frRGN_OR = 0x3;
extern PACKAGE Qt::QRegionH* __fastcall frCreateRectRgn(int p1, int p2, int p3, int p4);
extern PACKAGE void __fastcall frDeleteRgn(Qt::QRegionH* p1);
extern PACKAGE void __fastcall frGetClipRgn(Qt::QPainterH* DC, Qt::QRegionH* &p2);
extern PACKAGE void __fastcall frSetClipRgn(Qt::QPainterH* DC, Qt::QRegionH* p2);
extern PACKAGE void __fastcall frExcludeClipRect(Qt::QPainterH* DC, int p2, int p3, int p4, int p5);
extern PACKAGE void __fastcall frExcludeClipRgn(Qt::QPainterH* DC, Qt::QRegionH* p2);
extern PACKAGE void __fastcall frCombineRgn(Qt::QRegionH* &p1, Qt::QRegionH* &p2, Qt::QRegionH* &p3);
extern PACKAGE bool __fastcall frPtInRegion(Qt::QRegionH* p1, int p2, int p3);
extern PACKAGE bool __fastcall frRectVisible(Qt::QPainterH* DC, const Types::TRect &ARect);
extern PACKAGE void __fastcall frSetTextCharacterExtra(Qt::QPainterH* DC, int p2);

}	/* namespace Fr_api */
using namespace Fr_api;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// fr_api
