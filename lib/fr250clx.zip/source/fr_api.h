//---------------------------------------------------------------------------

#ifndef fr_apiH
#define fr_apiH
//---------------------------------------------------------------------------

#include <Qt.hpp>
#include <Types.hpp>
#pragma hdrstop

typedef QRegion__ frHRGN;
typedef QPainter__ frHDC;
typedef QBrush__ frHBrush;

frHRGN __fastcall frCreateRectRgn(int p1, int p2, int p3, int p4);
void __fastcall frCombineRgn(frHRGN * p1, frHRGN * p2, frHRGN * p3);
int __fastcall frPtInRegion(frHRGN p1, int p2, int p3);
int __fastcall frRectVisible(frHDC DC, TRect ARect);
int __fastcall frSetTextCharacterExtra(frHDC DC, int p2);
void __fastcall frDeleteRgn(frHRGN p1);
void __fastcall frGetClipRgn(frHDC DC, frHRGN* p2);
void __fastcall frSetClipRgn(frHDC DC, frHRGN p2);
void __fastcall frExcludeClipRect(frHDC DC, int p2, int p3, int p4, int p5);
void __fastcall frExcludeClipRgn(frHDC DC, frHRGN p2);

#endif

