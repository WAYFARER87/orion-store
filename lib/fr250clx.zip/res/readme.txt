Just copy all files from desired folder to the FR\SOURCE and recompile
the FR package.